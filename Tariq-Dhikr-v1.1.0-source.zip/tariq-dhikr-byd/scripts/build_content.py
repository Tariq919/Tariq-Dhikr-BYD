"""Build offline selections from unchanged QuranEnc verse/translation records.

Run from the project root with --cache pointing at downloaded source databases.
Arabic is retrieved by the documented QuranEnc sura API. No religious text is generated.
"""
import argparse
import concurrent.futures
import hashlib
import json
import sqlite3
import time
import urllib.request
from pathlib import Path

DUA = {
    1:[6], 2:[127,128,201,250,286], 3:[8,9,16,38,53,147,191,193,194],
    7:[23,126,151,156], 10:[85,86], 12:[101], 14:[35,40,41],17:[24,80],
    18:[10],20:[25,26,27,28,114],21:[83,87,89],23:[29,97,98,109,118],
    25:[65,74],26:[83,84,85],27:[19],28:[16,21,24],40:[7,8,9],59:[10],
    66:[8,11],71:[28]
}
DHIKR = {1:[1,2,3,4,5],17:[111],33:[41,42],37:[159,180,181,182],50:[39],56:[74],59:[22,23,24],87:[1]}
REFLECTION = {2:[152,153,156,186],3:[173],9:[51,129],10:[57,58,62,63,64],11:[90,115],12:[86,87],13:[28],14:[7],16:[97],39:[53],40:[60],48:[4],65:[3],94:[5,6]}
MOODS = {
    'sad':'2:156 9:129 10:57 11:90 12:86 12:87 13:28 21:83 21:87 21:89 28:24 39:53 48:4 94:5 94:6',
    'anxious':'1:6 2:153 2:186 2:286 3:8 3:173 9:51 9:129 10:85 10:86 13:28 18:10 20:25 20:26 23:97 23:98 28:21 40:60 48:4 65:3',
    'lonely':'2:186 9:129 12:86 13:28 18:10 21:89 28:24 39:53 40:60 48:4',
    'grateful':'1:1 1:2 1:3 1:4 1:5 2:127 2:152 3:191 10:58 14:7 16:97 17:111 27:19 33:41 33:42 37:182 59:22 59:23 59:24 87:1',
    'patient':'2:153 2:156 2:250 2:286 3:147 3:173 7:126 9:51 11:115 12:86 12:87 21:83 21:87 65:3 94:5 94:6',
    'hope':'2:128 2:186 2:201 3:8 3:9 3:16 3:38 3:53 3:193 3:194 7:23 7:151 7:156 11:90 12:87 14:40 14:41 17:80 18:10 21:87 23:109 23:118 25:74 26:83 26:84 26:85 28:16 39:53 40:7 40:8 40:9 40:60 59:10 66:8 66:11 71:28 94:5 94:6',
    'peace':'1:2 1:3 1:5 1:6 2:201 3:191 10:58 10:62 10:63 10:64 13:28 16:97 20:114 23:29 33:41 33:42 37:159 37:180 37:181 37:182 48:4 50:39 56:74 59:22 59:23 59:24 87:1'
}
LANGUAGES = {'en':'english_rwwad','ur':'urdu_junagarhi','id':'indonesian_affairs','bn':'bengali_zakaria','tr':'turkish_rwwad','fa':'persian_ih','ms':'malay_basumayyah','fr':'french_rashid','sw':'swahili_rwwad'}

SURAH_NAMES = {
 1:['الفاتحة','Al-Fatihah'],2:['البقرة','Al-Baqarah'],3:['آل عمران','Ali Imran'],7:['الأعراف',"Al-A'raf"],9:['التوبة','At-Tawbah'],10:['يونس','Yunus'],11:['هود','Hud'],12:['يوسف','Yusuf'],13:['الرعد',"Ar-Ra'd"],14:['إبراهيم','Ibrahim'],16:['النحل','An-Nahl'],17:['الإسراء','Al-Isra'],18:['الكهف','Al-Kahf'],20:['طه','Ta-Ha'],21:['الأنبياء','Al-Anbiya'],23:['المؤمنون',"Al-Mu'minun"],25:['الفرقان','Al-Furqan'],26:['الشعراء',"Ash-Shu'ara"],27:['النمل','An-Naml'],28:['القصص','Al-Qasas'],33:['الأحزاب','Al-Ahzab'],37:['الصافات','As-Saffat'],39:['الزمر','Az-Zumar'],40:['غافر','Ghafir'],48:['الفتح','Al-Fath'],50:['ق','Qaf'],56:['الواقعة',"Al-Waqi'ah"],59:['الحشر','Al-Hashr'],65:['الطلاق','At-Talaq'],66:['التحريم','At-Tahrim'],71:['نوح','Nuh'],87:['الأعلى',"Al-A'la"],94:['الشرح','Ash-Sharh']
}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--cache',required=True);args=parser.parse_args()
    cache=Path(args.cache); project=Path(__file__).resolve().parents[1]; assets=project/'app/src/main/assets'
    kinds={}
    for kind,group in [('dua',DUA),('dhikr',DHIKR),('reflection',REFLECTION)]:
        for s,verses in group.items():
            for a in verses:
                assert (s,a) not in kinds;kinds[s,a]=kind
    assert len(kinds)==100,len(kinds)
    metadata={x['key']:x for x in json.loads((cache/'translations.json').read_text())['translations']}
    metadata['bengali_zakaria']={'key':'bengali_zakaria','title':'Bengali Translation — Dr. Abu Bakr Muhammad Zakaria','description':'Translated by Dr. Abu Bakr Muhammad Zakaria. QuranEnc published edition.','version':'1.1.1','last_update':'2021-05-22','language_iso_code':'bn','direction':'ltr'}
    metadata['malay_basumayyah']={'key':'malay_basumayyah','title':'Malay Translation — Abdullah Muhammad Basmeih','description':'Translated by Abdullah Muhammad Basmeih. QuranEnc published edition.','version':'1.0.0','last_update':'2021-01-27','language_iso_code':'ms','direction':'ltr'}
    def get_sura(s):
        p=cache/('arabic-sura-'+str(s)+'.json')
        if not p.exists():
            url='https://quranenc.com/api/v1/translation/sura/english_rwwad/'+str(s)
            for attempt in range(3):
                try:
                    with urllib.request.urlopen(url,timeout=35) as f:data=f.read()
                    assert isinstance(json.loads(data)['result'],list);p.write_bytes(data);break
                except Exception:
                    if attempt==2:raise
                    time.sleep(1)
        return json.loads(p.read_text())['result']
    arabic={}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
        for rows in ex.map(get_sura,sorted({s for s,a in kinds})):
            for x in rows:arabic[int(x['sura']),int(x['aya'])]=x['arabic_text']
    translations={}
    sources={}
    for lang,key in LANGUAGES.items():
        m=dict(metadata[key]); m['source']='QuranEnc.com';m['url']='https://quranenc.com/en/browse/'+key
        db=cache/(key+'.sqlite')
        if db.exists():
            conn=sqlite3.connect(db)
            records={(int(s),int(a)):(t,n or '') for s,a,t,n in conn.execute('select sura,aya,translation,footnotes from translations')};conn.close()
            m['file_sha256']=hashlib.sha256(db.read_bytes()).hexdigest()
        else:
            records={}
            def fetch_translation(s):
                path=cache/(key+'-sura-'+str(s)+'.json')
                if not path.exists():
                    with urllib.request.urlopen('https://quranenc.com/api/v1/translation/sura/'+key+'/'+str(s),timeout=40) as f:path.write_bytes(f.read())
                return json.loads(path.read_text())['result']
            with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
                for rows in ex.map(fetch_translation,sorted({s for s,a in kinds})):
                    for x in rows:records[int(x['sura']),int(x['aya'])]=(x['translation'],x.get('footnotes',''))
        translations[lang]=records;sources[lang]=m
    entries=[]
    for (s,a),kind in sorted(kinds.items()):
        key=str(s)+':'+str(a)
        entry={'id':'q'+str(s)+'_'+str(a),'type':'quran','kind':kind,'sura':s,'aya':a,'surahName':SURAH_NAMES[s],'text':arabic[s,a],'extent':'full','moods':[m for m,refs in MOODS.items() if key in refs.split()], 'translations':{}}
        for lang,records in translations.items():
            t,notes=records[s,a];assert t.strip(),(lang,key)
            entry['translations'][lang]={'text':t,'footnotes':notes}
        entries.append(entry)
    # Preserve traditional counters/favorites as a clearly separate Arabic archive.
    legacy=json.loads((project/'data/legacy-1.0.json').read_text())
    aliases={'d01':'q2_201','d02':'q7_23','d03':'q3_8','d04':'q20_114','d05':['q20_25','q20_26'],'d06':'q21_87','d07':'q23_118','d08':'q17_24','d09':'q25_74','d10':'q28_24','d11':'q27_19','d12':'q2_127','d13':'q2_250','d14':'q66_8'}
    references={
        'd15':'صحيح مسلم، كتاب الحج، دعاء السفر، حديث 1342 — مقتطف',
        'd16':'صحيح مسلم، كتاب الذكر والدعاء، حديث 2721',
        'd17':'سنن الترمذي، كتاب الدعوات، حديث 3513',
        'd18':'سنن أبي داود، كتاب الوتر، حديث 1522؛ والنسائي 1303',
        'd19':'النسائي، السنن الكبرى، عمل اليوم والليلة، حديث 10405',
        'd20':'صحيح مسلم، كتاب الصلاة، حديث 483',
        'd21':'سنن أبي داود، كتاب الأدب، حديث 5074 — مقتطف',
        'd22':'صحيح مسلم، كتاب الذكر والدعاء، حديث 2722 — مقتطف',
        'z01':'صحيح مسلم، كتاب الآداب، حديث 2137 — من الأذكار الواردة',
        'z02':'صحيح مسلم، كتاب الآداب، حديث 2137 — من الأذكار الواردة',
        'z03':'صحيح مسلم، كتاب الآداب، حديث 2137 — من الأذكار الواردة',
        'z04':'صحيح مسلم، كتاب الآداب، حديث 2137 — من الأذكار الواردة',
        'z05':'صحيح البخاري 6406؛ وصحيح مسلم 2694',
        'z06':'صحيح البخاري 6405؛ وصحيح مسلم 2691',
        'z07':'صحيح البخاري 6384؛ وصحيح مسلم 2704',
        'z08':'صحيح البخاري، كتاب الدعوات، حديث 6307',
        'z09':'صحيح مسلم، كتاب الآداب، حديث 2137',
        'z10':'صحيح البخاري 3293؛ وصحيح مسلم 2691',
        'z11':'صحيح مسلم، كتاب الذكر والدعاء، حديث 2726',
        'z12':'صحيح البخاري 3370؛ وصحيح مسلم 406 — مقتطف من الصلاة الإبراهيمية'
    }
    for row in legacy:
        if row['id'] in aliases:continue
        row.update({'kind':row['type'],'type':'legacy','extent':'excerpt' if row['id'] in ['d15','d21','z12'] else 'full','moods':[],'translations':{}})
        row['source']=references[row['id']]
        if row['id']=='d22':row['extent']='excerpt'
        if row['id']=='d21':row['text']='اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ'
        entries.append(row)
    data={'catalog':entries,'sources':sources,'aliases':aliases,'retrieved':'2026-10-26','source':'https://quranenc.com','license':'https://old.quranenc.com/ar/home#terms'}
    (assets/'content.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
    (assets/'catalog.js').write_text('(function(r){var data='+json.dumps(data,ensure_ascii=False,separators=(',',':')).replace(chr(8232),'\\u2028').replace(chr(8233),'\\u2029')+';r.DHIKR_CATALOG=data.catalog;r.QURAN_SOURCES=data.sources;r.DHIKR_ALIASES=data.aliases;if(typeof module!=="undefined"&&module.exports)module.exports=data;})(typeof window!=="undefined"?window:this);\n')
    print('Built',len(entries),'entries:',len(kinds),'complete Quran verses and',len(entries)-len(kinds),'archived traditional entries, with',len(sources),'unaltered QuranEnc translations.')

if __name__=='__main__':main()
