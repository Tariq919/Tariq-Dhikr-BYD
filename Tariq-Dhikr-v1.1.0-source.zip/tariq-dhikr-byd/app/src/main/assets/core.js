(function(r){
 'use strict';
 var modes=['all','dua','dhikr','favorites','counter','legacy'];
 var langs=['ar','en','ur','id','bn','tr','fa','ms','fr','sw'];
 function bounded(v,a,b,d){return typeof v==='number'&&isFinite(v)?Math.max(a,Math.min(b,Math.round(v))):d;}
 function normalize(input,catalog,aliases){
  var s=input&&typeof input==='object'?input:{},ids=catalog.map(function(x){return x.id;}),counters={},favorites=[],language=langs.indexOf(s.language)>=0?s.language:'ar';
  (Array.isArray(s.favorites)?s.favorites:[]).forEach(function(id){var mapped=aliases&&aliases[id]||id;(Array.isArray(mapped)?mapped:[mapped]).forEach(function(target){if(ids.indexOf(target)>=0&&favorites.indexOf(target)<0)favorites.push(target);});});
  catalog.forEach(function(x){if(x.kind==='dhikr')counters[x.id]=bounded(s.counters&&s.counters[x.id],0,999999,0);});
  var current=aliases&&aliases[s.current]||s.current;if(Array.isArray(current))current=current[0];
  return {schema:2,language:language,translationLang:langs.indexOf(s.translationLang)>0?s.translationLang:'en',displayMode:['arabic','both','translation'].indexOf(s.displayMode)>=0?s.displayMode:(language==='ar'?'arabic':'both'),mode:modes.indexOf(s.mode)>=0?s.mode:'all',seconds:[30,45,60,90,120].indexOf(s.seconds)>=0?s.seconds:45,font:bounded(s.font,28,80,46),brightness:bounded(s.brightness,0,2,s.dim?1:0),auto:s.auto!==false,askMood:s.askMood!==false,favorites:favorites,counters:counters,current:ids.indexOf(current)>=0?current:catalog[0].id};
 }
 function select(catalog,state,mood){return catalog.filter(function(x){
  if(state.mode==='favorites')return state.favorites.indexOf(x.id)>=0&&(state.language==='ar'||x.type==='quran');
  if(state.mode==='legacy')return x.type==='legacy';
  if(state.mode==='counter')return x.kind==='dhikr'&&(state.language==='ar'||x.type==='quran');
  if(x.type!=='quran')return false;
  if(mood&&x.moods.indexOf(mood)<0)return false;
  return state.mode==='all'||state.mode===x.kind;
 });}
 function step(list,id,direction){if(!list.length)return null;var i=list.map(function(x){return x.id;}).indexOf(id);return list[(Math.max(i,0)+direction+list.length)%list.length];}
 function reset(state,id,accepted){if(accepted===true&&Object.prototype.hasOwnProperty.call(state.counters,id))state.counters[id]=0;return state;}
 function paginate(text,fits){
  if(!text)return [];if(fits(text))return [text];
  var tokens=text.match(/\s*\S+\s*/g)||[text],pages=[],start=0;
  while(start<tokens.length){var lo=start+1,hi=tokens.length,best=start+1;
   while(lo<=hi){var mid=Math.floor((lo+hi)/2);if(fits(tokens.slice(start,mid).join(''))){best=mid;lo=mid+1;}else hi=mid-1;}
   pages.push(tokens.slice(start,best).join(''));start=best;
  }return pages;
 }
 var api={normalize:normalize,select:select,step:step,reset:reset,paginate:paginate,languages:langs};r.DhikrCore=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:this);
