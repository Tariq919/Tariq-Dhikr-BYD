(function(){
 'use strict';
 var $=function(id){return document.getElementById(id);},core=window.DhikrCore,catalog=window.DHIKR_CATALOG,languages=window.DHIKR_LANGUAGES,sources=window.QURAN_SOURCES;
 var dream=location.hash==='#dream',stored={};try{stored=JSON.parse(window.DhikrStorage?window.DhikrStorage.load():localStorage.getItem('tariq-dhikr')||'{}');}catch(ignore){}
 var state=core.normalize(stored,catalog,window.DHIKR_ALIASES),mood='',list=[],current=null,pages=[],pageIndex=0,timer=null,hideTimer=null,resizeTimer=null,toastTimer=null,visible=true,pendingResetId=null,measuring=false,pageCacheKey='';
 var dialogOrder=['confirmDialog','detailsDialog','settings','moodDialog'];
 function t(key){return languages[state.language].text[key]||languages.en.text[key]||key;}
 function num(n){var str=String(n);if(state.language==='ar')return str.replace(/[0-9]/g,function(c){return '٠١٢٣٤٥٦٧٨٩'[Number(c)];});return str;}
 function save(){if(dream)return;try{var text=JSON.stringify(state);if(window.DhikrStorage)window.DhikrStorage.save(text);else localStorage.setItem('tariq-dhikr',text);}catch(ignore){}}
 function meaningLang(){return state.language==='ar'?state.translationLang:state.language;}
 function isOpen(){for(var i=0;i<dialogOrder.length;i++)if(!$(dialogOrder[i]).hidden)return true;return false;}
 function topDialog(){for(var i=0;i<dialogOrder.length;i++)if(!$(dialogOrder[i]).hidden)return $(dialogOrder[i]);return null;}
 function toast(text){$('toast').textContent=text;$('toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(function(){$('toast').classList.remove('visible');},1800);}
 function applyLanguage(){
  document.documentElement.lang=state.language;document.documentElement.dir=languages[state.language].dir;
  var nodes=document.querySelectorAll('[data-i18n]');for(var i=0;i<nodes.length;i++)nodes[i].textContent=t(nodes[i].getAttribute('data-i18n'));
  $('language').value=state.language;$('welcomeLanguage').value=state.language;$('mode').value=state.mode;$('displayMode').value=state.displayMode;$('meaningLanguage').value=state.translationLang;$('meaningLanguageRow').hidden=state.language!=='ar';$('meaningLanguageLabel').textContent=t('meaning')+' · '+t('language');
  $('translation').dir=languages[meaningLang()].dir;$('translation').lang=meaningLang();
  var family=meaningLang()==='bn'?'NotoBengali,Amiri,Arial,sans-serif':(['ur','fa'].indexOf(meaningLang())>=0?'Amiri,Tahoma,serif':'Arial,Tahoma,sans-serif');['translation','fullTranslation','footnotes'].forEach(function(id){$(id).style.fontFamily=family;$(id).style.textAlign=languages[meaningLang()].dir==='rtl'?'right':'left';});
  $('fullTranslation').dir=languages[meaningLang()].dir;$('fullTranslation').lang=meaningLang();$('footnotes').dir=languages[meaningLang()].dir;
  $('stage').setAttribute('aria-label',t('content'));$('nightButton').textContent=t(state.brightness===2?'day':'night');
  var choices=$('moodChoices').querySelectorAll('button');for(i=0;i<choices.length;i++)choices[i].textContent=t(choices[i].getAttribute('data-mood'));
  $('fontValue').textContent=num(state.font);$('mode').querySelector('option[value=legacy]').disabled=state.language!=='ar';
 }
 function brightness(){document.body.classList.toggle('dim',state.brightness===1);document.body.classList.toggle('night',state.brightness===2);$('nightButton').textContent=t(state.brightness===2?'day':'night');$('nightButton').setAttribute('aria-pressed',String(state.brightness===2));}
 function controls(show){if(dream)return;document.body.classList.toggle('quiet',!show);clearTimeout(hideTimer);if(show&&!isOpen()&&state.mode!=='counter')hideTimer=setTimeout(function(){controls(false);},10000);if(current&&!measuring)reflow();}
 function syncModal(){var open=isOpen();$('scrim').hidden=!open;$('app').setAttribute('aria-hidden',String(open));$('app').inert=open;clearTimeout(hideTimer);if(open){document.body.classList.remove('quiet');clearTimeout(timer);}else{controls(true);schedule();}}
 function showDialog(id,show){$(id).hidden=!show;syncModal();if(show){var focus=$(id).querySelector('button,select');if(focus)focus.focus();}else{var remaining=topDialog();var target=remaining?remaining.querySelector('button,select'):$('stage');if(target)target.focus();}}
 function reference(item){return item.type==='quran'?(state.language==='ar'?'سورة '+item.surahName[0]:item.surahName[1])+' · '+num(item.sura)+':'+num(item.aya):item.source;}
 function extent(item){return t(item.type==='quran'?'fullVerse':item.extent==='excerpt'?'excerpt':'fullDhikr');}
 function translation(item){var translated=item&&item.translations[meaningLang()];return translated?translated.text:'';}
 function drawPage(p,index,total){
  $('arabic').textContent=p.arabic||'';$('arabic').hidden=!p.arabic;
  $('translation').textContent=p.translation||'';$('translation').hidden=!p.translation;
  $('translationLabel').textContent=p.translation?t('meaning')+' · '+languages[meaningLang()].name:'';$('translationLabel').hidden=!p.translation;
  $('part').textContent=total>1?t('readingPart')+' '+num(index+1)+' / '+num(total):'';
  $('part').hidden=total<=1;
 }
 function reflow(){
  if(!current||measuring)return;measuring=true;
  $('arabic').style.fontSize=state.font+'px';$('translation').style.fontSize=Math.max(20,Math.round(state.font*.62))+'px';
  var fullArabic=current.text,fullTranslation=translation(current),mode=current.type==='legacy'?'arabic':state.displayMode;
  var key=current.id+'|'+meaningLang()+'|'+mode,anchorField='',anchorOffset=0;
  if(pageCacheKey===key&&pages[pageIndex]){anchorField=pages[pageIndex].arabic?'arabic':'translation';for(var previousIndex=0;previousIndex<pageIndex;previousIndex++)anchorOffset+=(pages[previousIndex][anchorField]||'').length;}
  if(state.language==='ar'&&mode==='translation'&&!fullTranslation)mode='arabic';
  var arabic=mode==='translation'?'':fullArabic,meaning=mode==='arabic'?'':fullTranslation;
  var stage=$('stage'),reading=$('reading'),limit=Math.max(100,stage.clientHeight-28);
  function fits(a,b){drawPage({arabic:a,translation:b},998,999);return !stage.clientHeight||reading.scrollHeight<=limit;}
  pages=[];
  if(fits(arabic,meaning))pages=[{arabic:arabic,translation:meaning}];
  else{
   if(arabic){core.paginate(arabic,function(v){return fits(v,'');}).forEach(function(v){pages.push({arabic:v,translation:''});});}
   if(meaning){core.paginate(meaning,function(v){return fits('',v);}).forEach(function(v){pages.push({arabic:'',translation:v});});}
  }
  if(!pages.length)pages=[{arabic:fullArabic,translation:''}];
  if(anchorField){var offset=0;for(var candidate=0;candidate<pages.length;candidate++){var length=(pages[candidate][anchorField]||'').length;if(length&&offset+length>anchorOffset){pageIndex=candidate;break;}offset+=length;}}pageCacheKey=key;
  pageIndex=Math.max(0,Math.min(pageIndex,pages.length-1));drawPage(pages[pageIndex],pageIndex,pages.length);stage.scrollTop=0;measuring=false;
 }
 function render(){
  list=core.select(catalog,state,mood);current=null;for(var i=0;i<list.length;i++)if(list[i].id===state.current)current=list[i];current=current||list[0]||null;
  $('reading').hidden=!current;$('empty').hidden=!!current;
  ['previous','next','favorite','pause','detailsButton'].forEach(function(id){$(id).disabled=!current;});
  $('countButton').hidden=state.mode!=='counter'||dream||!current;$('resetCounter').hidden=state.mode!=='counter'||!current;
  $('pause').hidden=state.mode==='counter';$('pause').textContent=t(state.auto?'pause':'play');$('pause').setAttribute('aria-pressed',String(!state.auto));
  if(current){
   state.current=current.id;$('kind').textContent=extent(current);$('source').textContent=reference(current);
   var liked=state.favorites.indexOf(current.id)>=0;$('favorite').textContent=liked?'★':'☆';$('favorite').setAttribute('aria-pressed',String(liked));$('favorite').setAttribute('aria-label',t(liked?'unfavorite':'favorite'));
   $('position').textContent=num(list.indexOf(current)+1)+' / '+num(list.length);$('count').textContent=num(state.counters[current.id]||0);reflow();
  }else{$('position').textContent='0 / 0';pages=[];}
  brightness();save();schedule();
 }
 function schedule(){clearTimeout(timer);if(!state.auto||!visible||isOpen()||!current||state.mode==='counter')return;
  var p=pages[pageIndex]||{},words=((p.arabic||'')+' '+(p.translation||'')).match(/\S+/g)||[];
  timer=setTimeout(function(){advance(1);},Math.max(state.seconds,Math.ceil(words.length*60/90))*1000);
 }
 function advance(direction){
  if(!current)return;
  if(direction>0&&pageIndex<pages.length-1){pageIndex++;drawPage(pages[pageIndex],pageIndex,pages.length);schedule();return;}
  if(direction<0&&pageIndex>0){pageIndex--;drawPage(pages[pageIndex],pageIndex,pages.length);schedule();return;}
  var next=core.step(list,state.current,direction);if(next){state.current=next.id;pageIndex=0;render();if(direction<0){pageIndex=pages.length-1;drawPage(pages[pageIndex],pageIndex,pages.length);schedule();}}
 }
 function settings(show){
  if(show){$('mode').value=state.mode;$('displayMode').value=state.displayMode;$('seconds').value=String(state.seconds);$('font').value=state.font;$('brightness').value=state.brightness;$('auto').checked=state.auto;$('askMood').checked=state.askMood;}
  showDialog('settings',show);
 }
 function changeLanguage(value){state.language=value;if(value!=='ar'&&state.mode==='legacy')state.mode='all';if(value!=='ar'){state.translationLang=value;if(state.displayMode==='arabic')state.displayMode='both';}pageIndex=0;applyLanguage();render();save();}
 function chooseMood(value){mood=value;state.mode='all';pageIndex=0;showDialog('moodDialog',false);render();}
 function showDetails(){if(!current)return;var m=current.translations[meaningLang()],credit=sources[meaningLang()];
  $('detailsReference').textContent=extent(current)+' · '+reference(current);$('fullArabic').textContent=current.text;$('fullTranslation').textContent=m?m.text:t('noTranslation');
  $('translationCredit').textContent=m?credit.title+' · QuranEnc.com · v'+credit.version+'\n'+credit.description+'\n'+credit.url:'';
  $('footnotes').textContent=m&&m.footnotes?m.footnotes.replace(/<\/?b>/g,'').replace(/\\n/g,'\n'):t('noFootnotes');showDialog('detailsDialog',true);
 }
 window.DhikrVisibility=function(isVisible){visible=!!isVisible;schedule();};
 window.DhikrBack=function(){
  if(!$('confirmDialog').hidden){pendingResetId=null;showDialog('confirmDialog',false);return true;}
  if(!$('detailsDialog').hidden){showDialog('detailsDialog',false);return true;}
  if(!$('settings').hidden){settings(false);return true;}
  if(!$('moodDialog').hidden){chooseMood('');return true;}
  return false;
 };
 function init(){
  var langSelects=[$('language'),$('welcomeLanguage')];for(var k in languages)if(Object.prototype.hasOwnProperty.call(languages,k)){for(var j=0;j<langSelects.length;j++){var opt=document.createElement('option');opt.value=k;opt.textContent=languages[k].name;langSelects[j].appendChild(opt);}if(k!=='ar'){var meaningOption=document.createElement('option');meaningOption.value=k;meaningOption.textContent=languages[k].name;$('meaningLanguage').appendChild(meaningOption);}}
  ['peace','sad','anxious','lonely','grateful','patient','hope'].forEach(function(m){var b=document.createElement('button');b.setAttribute('data-mood',m);b.onclick=function(){chooseMood(m);};$('moodChoices').appendChild(b);});
  $('meaningLanguage').onchange=function(){state.translationLang=this.value;pageIndex=0;applyLanguage();render();};
  $('language').onchange=function(){changeLanguage(this.value);};$('welcomeLanguage').onchange=function(){changeLanguage(this.value);};
  $('settingsButton').onclick=function(){settings(true);};$('closeSettings').onclick=function(){settings(false);};$('moodButton').onclick=function(){showDialog('moodDialog',true);};$('skipMood').onclick=function(){chooseMood('');};
  $('nightButton').onclick=function(){state.brightness=state.brightness===2?0:2;brightness();save();};
  $('brightness').onchange=function(){state.brightness=Number(this.value);brightness();save();};
  $('previous').onclick=function(){advance(-1);};$('next').onclick=function(){advance(1);};$('pause').onclick=function(){state.auto=!state.auto;render();};$('hide').onclick=function(){controls(false);};
  $('favorite').onclick=function(){if(!current)return;var i=state.favorites.indexOf(current.id);if(i<0)state.favorites.push(current.id);else state.favorites.splice(i,1);render();};
  $('mode').onchange=function(){state.mode=this.value;mood='';pageIndex=0;render();};$('displayMode').onchange=function(){state.displayMode=this.value;pageIndex=0;render();};
  $('seconds').onchange=function(){state.seconds=Number(this.value);save();schedule();};$('font').oninput=function(){state.font=Number(this.value);$('fontValue').textContent=num(state.font);reflow();save();};
  $('auto').onchange=function(){state.auto=this.checked;render();};$('askMood').onchange=function(){state.askMood=this.checked;save();};
  $('countButton').onclick=function(){if(!current||state.mode!=='counter')return;state.counters[current.id]=Math.min(999999,(state.counters[current.id]||0)+1);$('count').textContent=num(state.counters[current.id]);save();};
  $('resetCounter').onclick=function(){if(current){pendingResetId=current.id;showDialog('confirmDialog',true);}};
  $('confirmReset').onclick=function(){core.reset(state,pendingResetId,true);pendingResetId=null;save();showDialog('confirmDialog',false);render();toast(t('saved'));};
  $('cancelReset').onclick=function(){pendingResetId=null;showDialog('confirmDialog',false);};
  $('detailsButton').onclick=showDetails;$('closeDetails').onclick=function(){showDialog('detailsDialog',false);};$('scrim').onclick=function(){window.DhikrBack();};
  $('stage').onclick=function(e){if(!e.target.closest('button'))controls(document.body.classList.contains('quiet'));};
  var buttons=document.querySelectorAll('.chrome button');for(var i=0;i<buttons.length;i++)buttons[i].addEventListener('click',function(){if(this.id!=='hide')controls(true);});
  document.addEventListener('keydown',function(e){var modal=topDialog();if(modal){if(e.key==='Escape'){window.DhikrBack();e.preventDefault();}if(e.key==='Tab'){var nodes=modal.querySelectorAll('button,select,input'),items=[];for(var n=0;n<nodes.length;n++)if(!nodes[n].hidden&&nodes[n].offsetParent!==null)items.push(nodes[n]);if(items.length){if(e.shiftKey&&document.activeElement===items[0]){items[items.length-1].focus();e.preventDefault();}else if(!e.shiftKey&&document.activeElement===items[items.length-1]){items[0].focus();e.preventDefault();}}}return;}
   if(e.key==='ArrowLeft'){advance(languages[state.language].dir==='rtl'?1:-1);controls(true);e.preventDefault();}if(e.key==='ArrowRight'){advance(languages[state.language].dir==='rtl'?-1:1);controls(true);e.preventDefault();}
  });
  document.addEventListener('visibilitychange',function(){visible=!document.hidden;schedule();});window.addEventListener('resize',function(){clearTimeout(resizeTimer);resizeTimer=setTimeout(function(){reflow();schedule();},180);});window.addEventListener('pagehide',save);
  if(document.fonts&&document.fonts.ready)document.fonts.ready.then(function(){reflow();});
  if(dream){document.body.classList.add('dream','quiet');if(state.mode==='counter')state.mode='dhikr';}
  applyLanguage();render();if(!dream&&state.askMood)showDialog('moodDialog',true);else controls(true);window.DHIKR_READY=true;$('loadError').hidden=true;
 }
 init();
})();
