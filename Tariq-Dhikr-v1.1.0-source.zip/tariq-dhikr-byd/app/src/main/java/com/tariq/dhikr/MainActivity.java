package com.tariq.dhikr;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import android.webkit.WebView;
import android.webkit.ValueCallback;

public final class MainActivity extends Activity {
    private WebView webView;
    private Object modernBack;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        webView = DhikrWebView.create(this, false);
        setContentView(webView);
        if (Build.VERSION.SDK_INT >= 33) modernBack = Api33.register(this);
        immerse();
    }
    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused) immerse();
        setPageVisible(focused);
    }
    private void immerse() {
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.systemBars());
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
            return;
        }
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }
    private void routeBack() {
        if (webView == null) { finish(); return; }
        webView.evaluateJavascript("(function(){return typeof window.DhikrBack === 'function' && window.DhikrBack();})()",
            new ValueCallback<String>() {
                @Override public void onReceiveValue(String result) { if (!"true".equals(result)) finish(); }
            });
    }
    private void setPageVisible(boolean visible) {
        if (webView != null) webView.evaluateJavascript(
            "if(typeof window.DhikrVisibility==='function'){window.DhikrVisibility(" + visible + ");}", null);
    }
    @Override public void onBackPressed() { routeBack(); }
    private static final class Api33 {
        static Object register(final MainActivity activity) {
            OnBackInvokedCallback callback = new OnBackInvokedCallback() {
                @Override public void onBackInvoked() { activity.routeBack(); }
            };
            activity.getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, callback);
            return callback;
        }
        static void unregister(MainActivity activity, Object callback) {
            activity.getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback((OnBackInvokedCallback) callback);
        }
    }
    @Override protected void onPause() { setPageVisible(false); webView.onPause(); webView.pauseTimers(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (webView != null) { webView.resumeTimers(); webView.onResume(); setPageVisible(true); } }
    @Override protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 33 && modernBack != null) Api33.unregister(this, modernBack);
        if (webView != null) { webView.removeJavascriptInterface("DhikrStorage"); webView.destroy(); }
        super.onDestroy();
    }
}
