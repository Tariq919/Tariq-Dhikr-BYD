const fs=require('fs'),vm=require('vm'),assert=require('assert/strict');const{parseHTML}=require('linkedom');
const root=require('node:path').resolve(__dirname,'../app/src/main/assets')+'/';
function launch(saved={},dream=false){
 const{window}=parseHTML(fs.readFileSync(root+'index.html','utf8'));const timers=new Map();let tid=0,writes=0,state=JSON.stringify(saved);
 Object.defineProperty(Object.getPrototypeOf(window.document.getElementById('mode')),'value',{get(){return this._value||this.querySelector('option')?.getAttribute('value')||''},set(v){this._value=v},configurable:true});
 window.HTMLElement.prototype.focus=function(){window.document._focused=this};
 window.HTMLElement.prototype.blur=function(){};
 // The renderer has no NodeList.forEach: old-WebView compatibility must not depend on it.
 const queryAll=window.document.querySelectorAll.bind(window.document);window.document.querySelectorAll=function(...a){const list=queryAll(...a);list.forEach=undefined;return list;};
 const sandbox={window,document:window.document,location:{hash:dream?'#dream':''},localStorage:{getItem:()=>state,setItem:(k,v)=>{state=v;writes++}},console,
 setTimeout:(cb,ms)=>{timers.set(++tid,{cb,ms});return tid},clearTimeout:id=>timers.delete(id),setInterval:()=>1};
 vm.createContext(sandbox);for(const f of ['i18n.js','catalog.js','core.js','app.js'])vm.runInContext(fs.readFileSync(root+f,'utf8'),sandbox,{filename:f});
 return{d:window.document,w:window,timers,getState:()=>JSON.parse(state),getWrites:()=>writes};
}
let a=launch(),$=id=>a.d.getElementById(id);assert.equal(a.w.DHIKR_READY,true);assert.equal($('moodDialog').hidden,false);$('moodChoices').querySelector('[data-mood=sad]').onclick();assert.equal($('moodDialog').hidden,true);assert.ok($('arabic').textContent.length);assert.equal(a.getState().mood,undefined);
$('settingsButton').onclick();assert.equal($('settings').hidden,false);assert.equal(a.w.DhikrBack(),true);assert.equal($('settings').hidden,true);assert.equal(a.w.DhikrBack(),false);
a=launch({askMood:false,mode:'counter',current:'z01',counters:{z01:33,z02:17}});$=id=>a.d.getElementById(id);
$('settingsButton').onclick();$('resetCounter').onclick();assert.equal($('confirmDialog').hidden,false);$('cancelReset').onclick();assert.equal(a.getState().counters.z01,33);assert.equal($('settings').hidden,false);
$('resetCounter').onclick();assert.equal(a.w.DhikrBack(),true);assert.equal(a.getState().counters.z01,33);
$('resetCounter').onclick();$('confirmReset').onclick();assert.equal(a.getState().counters.z01,0);assert.equal(a.getState().counters.z02,17);assert.equal($('confirmDialog').hidden,true);a.w.DhikrBack();
$('countButton').onclick();assert.equal(a.getState().counters.z01,1);const saved=a.getState();a=launch(saved);assert.equal(a.getState().counters.z01,1);
for(const language of ['ar','en','ur','id','bn','tr','fa','ms','fr','sw']){a=launch({askMood:false,language,displayMode:language==='ar'?'arabic':'both',current:'q2_286'});assert.equal(a.w.DHIKR_READY,true);assert.equal(a.d.documentElement.lang,language);assert.equal(a.d.documentElement.dir,['ar','ur','fa'].includes(language)?'rtl':'ltr');if(language!=='ar')assert.ok(a.d.getElementById('translation').textContent.length>0);a.d.getElementById('detailsButton').onclick();assert.ok(a.d.getElementById('translationCredit').textContent.includes('QuranEnc.com'));}
a=launch({askMood:false,language:'en'});a.d.getElementById('nightButton').onclick();assert.equal(a.getState().brightness,2);assert.equal(a.d.body.classList.contains('night'),true);a.d.getElementById('nightButton').onclick();assert.equal(a.getState().brightness,0);
a=launch({mode:'counter',counters:{z01:44}},true);assert.equal(a.getWrites(),0);assert.equal(a.d.getElementById('moodDialog').hidden,true);
console.log('PASS: startup mood/skip; no NodeList.forEach; settings/back; cancel/confirm/back-out reset; one-counter persistence; all ten languages/directions; translation attribution; night mode; dream state isolation.');

a=launch({askMood:false,seconds:45});assert.ok(Array.from(a.timers.values()).some(x=>x.ms===45000));a.w.DhikrVisibility(false);assert.ok(!Array.from(a.timers.values()).some(x=>x.ms===45000));a.w.DhikrVisibility(true);assert.ok(Array.from(a.timers.values()).some(x=>x.ms===45000));console.log('PASS: native visibility hook suspends/resumes page rotation.');

a=launch({askMood:false,language:'ar',mode:'legacy',displayMode:'arabic'});a.d.getElementById('settingsButton').onclick();a.d.getElementById('language').value='en';a.d.getElementById('language').onchange();assert.equal(a.getState().mode,'all');assert.equal(a.d.getElementById('mode').value,'all');assert.equal(a.d.getElementById('displayMode').value,'both');console.log('PASS: changing language keeps settings controls in sync with displayed content.');
