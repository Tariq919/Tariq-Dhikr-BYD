# Downloads

The signed v1.1.0 APK and source archive are published in the GitHub release for this project. Version code 110 uses the same dedicated release certificate as v1.0.0. See the repository README for installation and the verification file for test limits.
