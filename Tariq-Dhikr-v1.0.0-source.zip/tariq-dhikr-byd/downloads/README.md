# Download

`Tariq-Dhikr-v1.0.0.apk` is the signed release APK (version code 2) for Android 6.0 and later. It is signed using a dedicated private release key; the key is not in this repository. Verify its SHA-256 using `SHA256SUMS`.

The source and packaged assets match this repository. Compilation and APK signature checks pass; physical BYD-device compatibility has not been verified. BYD firmware may restrict sideloading. If you installed the previous debug-signed test build, Android may require removing that build first because its signature differs; removing it clears local settings and counters.
