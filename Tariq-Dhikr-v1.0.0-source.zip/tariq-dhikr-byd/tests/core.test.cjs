const {test}=require('node:test');
const assert=require('node:assert/strict');
const catalog=require('../app/src/main/assets/catalog.js');
const core=require('../app/src/main/assets/core.js');

test('all 34 entries have unique IDs, Arabic text, and references',()=>{
  assert.equal(catalog.length,34);
  assert.equal(new Set(catalog.map(x=>x.id)).size,catalog.length);
  for(const item of catalog){assert.match(item.text,/[\u0600-\u06ff]/);assert.ok(item.source.length>5);assert.ok(['dua','dhikr'].includes(item.type));}
});
test('filters isolate supplications, dhikr and counter entries',()=>{
  const s=core.normalize({},catalog);
  assert.equal(core.select(catalog,s).length,34);
  s.mode='dua';assert.equal(core.select(catalog,s).length,22);
  s.mode='dhikr';assert.equal(core.select(catalog,s).length,12);
  s.mode='counter';assert.ok(core.select(catalog,s).every(x=>x.type==='dhikr'));
});
test('empty favorites never silently show other entries',()=>{
  const s=core.normalize({mode:'favorites'},catalog);
  assert.deepEqual(core.select(catalog,s),[]);
  assert.equal(core.step([],s.current,1),null);
});
test('favorites survive reload and discard duplicate/deleted IDs',()=>{
  const s=core.normalize({mode:'favorites',favorites:['d01','d01','missing','z01']},catalog);
  assert.deepEqual(s.favorites,['d01','z01']);
  assert.deepEqual(core.select(catalog,s).map(x=>x.id),['d01','z01']);
  assert.deepEqual(core.normalize(JSON.parse(JSON.stringify(s)),catalog),s);
});
test('navigation wraps in both directions',()=>{
  assert.equal(core.step(catalog,catalog[0].id,-1).id,catalog.at(-1).id);
  assert.equal(core.step(catalog,catalog.at(-1).id,1).id,catalog[0].id);
});
test('damaged or out-of-range saved settings cannot break display',()=>{
  const s=core.normalize({mode:'bad',font:Infinity,seconds:-2,counters:{z01:-3,z02:1e9,z03:'oops'},current:'deleted'},catalog);
  assert.equal(s.mode,'all');assert.equal(s.font,48);assert.equal(s.seconds,15);
  assert.equal(s.counters.z01,0);assert.equal(s.counters.z02,999999);assert.equal(s.counters.z03,0);
  assert.equal(s.current,catalog[0].id);
  assert.equal(core.normalize(null,catalog).seconds,45);
});
test('counter values are per-dhikr; no counter is created for a dua',()=>{
  const s=core.normalize({counters:{z01:33,z02:17,d01:99}},catalog);
  assert.equal(s.counters.z01,33);assert.equal(s.counters.z02,17);assert.equal(s.counters.d01,undefined);
});
