(function (root) {
  'use strict';
  var allowedModes = ['all','dua','dhikr','favorites','counter'];
  function bounded(value,min,max,fallback) {
    return typeof value === 'number' && isFinite(value) ? Math.max(min,Math.min(max,Math.round(value))) : fallback;
  }
  function normalize(input,catalog) {
    var s = input && typeof input === 'object' ? input : {};
    var ids = catalog.map(function(x){return x.id;});
    var favorites = Array.isArray(s.favorites) ? s.favorites.filter(function(id,i,a){return ids.indexOf(id)>=0 && a.indexOf(id)===i;}) : [];
    var counters = {};
    catalog.forEach(function(x){if(x.type==='dhikr') counters[x.id] = bounded(s.counters && s.counters[x.id],0,999999,0);});
    return {mode:allowedModes.indexOf(s.mode)>=0?s.mode:'all',seconds:bounded(s.seconds,15,180,45),
      font:bounded(s.font,28,80,48),dim:!!s.dim,auto:s.auto!==false,favorites:favorites,counters:counters,
      current:ids.indexOf(s.current)>=0?s.current:catalog[0].id};
  }
  function select(catalog,state) {
    return catalog.filter(function(x){
      if(state.mode==='favorites') return state.favorites.indexOf(x.id)>=0;
      if(state.mode==='counter') return x.type==='dhikr';
      return state.mode==='all'||x.type===state.mode;
    });
  }
  function step(list,id,direction) {
    if(!list.length) return null;
    var index = list.map(function(x){return x.id;}).indexOf(id);
    return list[(Math.max(index,0)+direction+list.length)%list.length];
  }
  var api = {normalize:normalize,select:select,step:step};
  root.DhikrCore = api;
  if(typeof module!=='undefined' && module.exports) module.exports=api;
})(typeof window!=='undefined'?window:this);
