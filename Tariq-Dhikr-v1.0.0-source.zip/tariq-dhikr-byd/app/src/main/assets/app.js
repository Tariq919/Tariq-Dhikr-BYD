(function(){
  'use strict';
  var $=function(id){return document.getElementById(id);};
  var catalog=window.DHIKR_CATALOG, core=window.DhikrCore;
  var dream=location.hash==='#dream', stored={};
  try{stored=JSON.parse(window.DhikrStorage?window.DhikrStorage.load():localStorage.getItem('tariq-dhikr')||'{}');}catch(e){}
  var state=core.normalize(stored,catalog), list=[], current=null, timer=null, hideTimer=null, toastTimer=null, open=false, visible=true;
  var digits='٠١٢٣٤٥٦٧٨٩';
  function ar(n){return String(n).replace(/[0-9]/g,function(c){return digits[Number(c)];});}
  function save(){if(dream)return;try{var value=JSON.stringify(state);if(window.DhikrStorage)window.DhikrStorage.save(value);else localStorage.setItem('tariq-dhikr',value);}catch(e){}}
  function toast(text){$('toast').textContent=text;$('toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(function(){$('toast').classList.remove('visible');},2000);}
  function fit(){
    if(!current)return;
    var stage=$('stage'), reading=$('reading');
    var size=state.font;
    document.documentElement.style.setProperty('--size',size+'px');
    while(reading.scrollHeight>stage.clientHeight-24 && size>22){size-=2;document.documentElement.style.setProperty('--size',size+'px');}
    // Very small displays or accessibility enlargement keep scroll access.
  }
  function render(){
    list=core.select(catalog,state);
    current=list.filter(function(x){return x.id===state.current;})[0]||list[0]||null;
    $('reading').hidden=!current;$('empty').hidden=!!current;
    ['previous','next','favorite','pause'].forEach(function(id){$(id).disabled=!current;});
    if(current){
      state.current=current.id;
      $('text').textContent=current.text;
      $('kind').textContent=(current.type==='dua'?'دعاء':'ذكر')+' · '+current.title;
      $('source').textContent=current.source;
      var liked=state.favorites.indexOf(current.id)>=0;
      $('favorite').textContent=liked?'★':'☆';
      $('favorite').setAttribute('aria-pressed',String(liked));
      $('favorite').setAttribute('aria-label',liked?'إزالة من المفضلة':'إضافة إلى المفضلة');
      $('position').textContent=ar(list.indexOf(current)+1)+' / '+ar(list.length);
      $('count').textContent=ar(state.counters[current.id]||0);
    }else{$('position').textContent='٠ / ٠';}
    $('countButton').hidden=state.mode!=='counter'||dream||!current;
    $('resetCounter').hidden=state.mode!=='counter'||!current;
    $('pause').textContent=state.auto?'إيقاف مؤقت':'تشغيل تلقائي';
    $('pause').setAttribute('aria-pressed',String(!state.auto));
    $('pause').hidden=state.mode==='counter';
    document.documentElement.style.setProperty('--ink',state.dim?'.58':'1');
    fit();save();schedule();
  }
  function schedule(){
    clearTimeout(timer);
    if(!state.auto||open||!visible||!current||state.mode==='counter'&&!dream)return;
    timer=setTimeout(function(){advance(1);},state.seconds*1000);
  }
  function advance(direction){var next=core.step(list,state.current,direction);if(next){state.current=next.id;render();}}
  function controls(show){
    if(dream)return;
    document.body.classList.toggle('quiet',!show);
    clearTimeout(hideTimer);
    if(show&&!open&&state.mode!=='counter') hideTimer=setTimeout(function(){
      var active=document.activeElement;
      if(active&&active.closest('.chrome'))active.blur();
      controls(false);
    },10000);
  }
  function panel(show){
    open=show;$('settings').hidden=!show;$('scrim').hidden=!show;
    $('app').setAttribute('aria-hidden',String(show));
    // inert is supported on newer head units; the focus trap covers older ones.
    $('app').inert=show;
    controls(true);
    if(show){
      $('mode').value=state.mode;$('seconds').value=String(state.seconds);
      if(!$('seconds').value)$('seconds').value='45';
      $('font').value=state.font;$('fontValue').textContent=ar(state.font);$('dim').checked=state.dim;$('auto').checked=state.auto;
      $('close').focus();
    }else{$('settingsButton').focus();}
    schedule();
  }
  $('stage').addEventListener('click',function(e){if(!e.target.closest('button'))controls(document.body.classList.contains('quiet'));});
  document.querySelectorAll('.chrome button').forEach(function(b){b.addEventListener('click',function(){controls(true);});});
  $('previous').onclick=function(){advance(-1);};$('next').onclick=function(){advance(1);};
  $('pause').onclick=function(){state.auto=!state.auto;render();};
  $('hide').onclick=function(){controls(false);};
  $('favorite').onclick=function(){if(!current)return;var i=state.favorites.indexOf(current.id);if(i>=0)state.favorites.splice(i,1);else state.favorites.push(current.id);render();};
  $('settingsButton').onclick=function(){panel(true);};$('close').onclick=function(){panel(false);};$('scrim').onclick=function(){panel(false);};
  $('mode').onchange=function(){state.mode=this.value;render();controls(true);};
  $('seconds').onchange=function(){state.seconds=Number(this.value);save();schedule();};
  $('font').oninput=function(){state.font=Number(this.value);$('fontValue').textContent=ar(state.font);fit();save();};
  $('dim').onchange=function(){state.dim=this.checked;render();};
  $('auto').onchange=function(){state.auto=this.checked;render();};
  $('countButton').onclick=function(){if(!current||state.mode!=='counter')return;state.counters[current.id]=Math.min(999999,(state.counters[current.id]||0)+1);$('count').textContent=ar(state.counters[current.id]);save();};
  $('resetCounter').onclick=function(){if(current&&confirm('تصفير عداد هذا الذكر؟')){state.counters[current.id]=0;render();toast('تم تصفير العداد');}};
  document.addEventListener('keydown',function(e){
    if(open){
      if(e.key==='Escape'){panel(false);e.preventDefault();}
      if(e.key==='Tab'){
        var items=Array.prototype.slice.call($('settings').querySelectorAll('button,select,input')).filter(function(x){return !x.hidden&&x.offsetParent!==null;});
        var first=items[0],last=items[items.length-1];
        if(e.shiftKey&&document.activeElement===first){last.focus();e.preventDefault();}
        else if(!e.shiftKey&&document.activeElement===last){first.focus();e.preventDefault();}
      }
      return;
    }
    if(e.key==='ArrowLeft'){advance(1);controls(true);e.preventDefault();}
    if(e.key==='ArrowRight'){advance(-1);controls(true);e.preventDefault();}
    if(e.key==='Escape')controls(true);
  });
  document.addEventListener('visibilitychange',function(){visible=!document.hidden;schedule();});
  window.addEventListener('resize',fit);
  window.addEventListener('pagehide',save);
  // Tiny periodic shifts reduce static placement. Not a burn-in guarantee.
  setInterval(function(){document.documentElement.style.setProperty('--shift-x',(Math.floor(Math.random()*13)-6)+'px');document.documentElement.style.setProperty('--shift-y',(Math.floor(Math.random()*9)-4)+'px');},60000);
  if(dream){document.body.classList.add('dream','quiet');state.mode=state.mode==='counter'?'dhikr':state.mode;}
  render();controls(true);
})();
