package com.tariq.dhikr;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** Entirely local content; no Internet, vehicle, overlay, or boot permissions. */
final class DhikrWebView {
    private DhikrWebView() {}

    @SuppressLint("SetJavaScriptEnabled")
    static WebView create(Context context, boolean dream) {
        WebView view = new WebView(context);
        view.setBackgroundColor(Color.BLACK);
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSupportZoom(false);
        view.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        view.addJavascriptInterface(new LocalState(context), "DhikrStorage");
        view.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                return true; // All navigation is handled inside the bundled page.
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) { return true; }
        });
        view.loadUrl("file:///android_asset/index.html" + (dream ? "#dream" : ""));
        return view;
    }

    static final class LocalState {
        private final SharedPreferences prefs;
        LocalState(Context context) { prefs = context.getSharedPreferences("dhikr", Context.MODE_PRIVATE); }
        @JavascriptInterface public String load() { return prefs.getString("state", "{}"); }
        @JavascriptInterface public void save(String state) {
            if (state != null && state.length() <= 32768) prefs.edit().putString("state", state).apply();
        }
    }
}
