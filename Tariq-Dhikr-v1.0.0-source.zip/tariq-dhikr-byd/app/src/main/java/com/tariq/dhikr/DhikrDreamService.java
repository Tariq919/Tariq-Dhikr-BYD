package com.tariq.dhikr;

import android.service.dreams.DreamService;
import android.webkit.WebView;

/** Optional standard Android screensaver. Availability depends on the head unit firmware. */
public final class DhikrDreamService extends DreamService {
    private WebView view;
    @Override public void onAttachedToWindow() {
        super.onAttachedToWindow();
        setInteractive(false);
        setFullscreen(true);
        setScreenBright(false);
        view = DhikrWebView.create(this, true);
        setContentView(view);
    }
    @Override public void onDreamingStarted() {
        super.onDreamingStarted();
        if (view != null) { view.resumeTimers(); view.onResume(); }
    }
    @Override public void onDreamingStopped() {
        if (view != null) { view.onPause(); view.pauseTimers(); }
        super.onDreamingStopped();
    }
    @Override public void onDetachedFromWindow() {
        if (view != null) { view.removeJavascriptInterface("DhikrStorage"); view.destroy(); view = null; }
        super.onDetachedFromWindow();
    }
}
